/**
 * http://usejsdoc.org/
 */

exports.execution = function(num1, num2){
	var result = 0;
	for(var i=num1; i <= num2; i++){
		result += i;
	}
	
	return result;
};