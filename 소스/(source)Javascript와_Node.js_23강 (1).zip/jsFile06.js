/**
 * http://usejsdoc.org/
 */

var req =require("request");

req("http://www.naver.com", function(error, response, body){
	console.log(body);
});
