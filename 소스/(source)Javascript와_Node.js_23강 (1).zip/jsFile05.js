/**
 * http://usejsdoc.org/
 */

var os = require("os");
console.log(os);

console.log("=======================================");

console.log("os.hostname() : " + os.hostname());
console.log("os.type() : " + os.type());
console.log("os.platform() : " + os.platform());
console.log("os.uptime() : " + os.uptime());
console.log("os.networkInterfaces() : " + os.networkInterfaces());