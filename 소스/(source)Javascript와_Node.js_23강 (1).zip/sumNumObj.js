/**
 * http://usejsdoc.org/
 */

var sumNum = {};

sumNum.execution = function(num1, num2){
	var result = 0;
	for(var i=num1; i <= num2; i++){
		result += i;
	}
	
	return result;
};

sumNum.executionOdd = function(num1, num2){
	var result = 0;
	for(var i=num1; i <= num2; i++){
		if(i % 2 != 0) 
			result += i;
	}
	
	return result;
};

module.exports = sumNum;