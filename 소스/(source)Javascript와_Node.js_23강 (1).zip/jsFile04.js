/**
 * http://usejsdoc.org/
 */

var sum = require("./sumNumObj");
console.log(sum.execution(0, 10));
console.log(sum.executionOdd(0, 10));