/**
 * http://usejsdoc.org/
 */

var sum = require("./sumNum");
console.log(sum.execution(0, 10));