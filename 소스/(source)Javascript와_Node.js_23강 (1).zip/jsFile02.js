/**
 * http://usejsdoc.org/
 */

var sum = {};
sum.execution = function(num1, num2){
	var result = 0;
	for(var i=num1; i <= num2; i++){
		result += i;
	}
	
	return result;
};

console.log(sum.execution(0, 10));